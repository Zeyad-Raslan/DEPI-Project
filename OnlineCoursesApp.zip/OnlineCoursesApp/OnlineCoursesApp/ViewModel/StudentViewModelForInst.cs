﻿namespace OnlineCoursesApp.ViewModel
{
    public class StudentViewModelForInst
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int Progress { get; set; }
    }
}
