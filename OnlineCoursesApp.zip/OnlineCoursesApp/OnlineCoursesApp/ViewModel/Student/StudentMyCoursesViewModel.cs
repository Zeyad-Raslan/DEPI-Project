﻿namespace OnlineCoursesApp.ViewModel.Student
{
    public class StudentMyCoursesViewModel
    {
       
        public string? CourseName { get; set; }
        public string InsrUctorName { get; set; }
        public string CourseDescription { get; set; }
    }
}
