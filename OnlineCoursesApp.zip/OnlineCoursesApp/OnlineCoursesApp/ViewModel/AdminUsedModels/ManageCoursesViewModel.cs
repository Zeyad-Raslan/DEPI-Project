﻿namespace OnlineCoursesApp.ViewModel.AdminUsedModels
{
    public class ManageCoursesViewModel : NewCourseViewModel
    {
        public int StudentNumber {  get; set; }
    }
}
