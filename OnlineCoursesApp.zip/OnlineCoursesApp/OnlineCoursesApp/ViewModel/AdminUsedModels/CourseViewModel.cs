﻿namespace OnlineCoursesApp.ViewModel.AdminUsedModels
{
    public class NewCourseViewModel
    {
        public int CourseId { get; set; }

        public string Name { get; set; } 

        public string Type { get; set; } 
    }
}
